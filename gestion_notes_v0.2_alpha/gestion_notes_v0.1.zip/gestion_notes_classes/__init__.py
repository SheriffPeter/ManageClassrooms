from .base import Base
from . import exceptions
from .promotion import Promotion
from .eleve import Eleve
from .examen import Examen


Base = Base
Promotion = Promotion
Eleve = Eleve
Examen = Examen
exceptions = exceptions
